﻿using System;
using System.Collections.Generic;

namespace ProjetQuizGabriel.Models
{
    public partial class Reponse
    {
        public int ReponseId { get; set; }
        public int OptionId { get; set; }
        public int QuizId { get; set; }

        public virtual Options Option { get; set; }
        public virtual Quiz Quiz { get; set; }
    }
}
