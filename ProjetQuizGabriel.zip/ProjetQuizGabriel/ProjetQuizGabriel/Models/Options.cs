﻿using System;
using System.Collections.Generic;

namespace ProjetQuizGabriel.Models
{
    public partial class Options
    {
        public Options()
        {
            Reponse = new HashSet<Reponse>();
        }

        public int OptionId { get; set; }
        public string Texte { get; set; }
        public bool BonneReponse { get; set; }
        public int QuestionId { get; set; }

        public virtual Question Question { get; set; }
        public virtual ICollection<Reponse> Reponse { get; set; }
    }
}
