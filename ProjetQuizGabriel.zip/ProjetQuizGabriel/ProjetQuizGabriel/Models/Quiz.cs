﻿using System;
using System.Collections.Generic;

namespace ProjetQuizGabriel.Models
{
    public partial class Quiz
    {
        public Quiz()
        {
            QuestionQuiz = new HashSet<QuestionQuiz>();
            Reponse = new HashSet<Reponse>();
        }

        public int QuizId { get; set; }
        public string NomUtilisateur { get; set; }
        public string Email { get; set; }

        public virtual ICollection<QuestionQuiz> QuestionQuiz { get; set; }
        public virtual ICollection<Reponse> Reponse { get; set; }
    }
}
