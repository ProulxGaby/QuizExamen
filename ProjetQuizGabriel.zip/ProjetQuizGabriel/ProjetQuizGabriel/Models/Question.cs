﻿using System;
using System.Collections.Generic;

namespace ProjetQuizGabriel.Models
{
    public partial class Question
    {
        public Question()
        {
            Options = new HashSet<Options>();
            QuestionQuiz = new HashSet<QuestionQuiz>();
        }

        public int QuestionId { get; set; }
        public string Texte { get; set; }
        public int CategorieId { get; set; }

        public virtual Categorie Categorie { get; set; }
        public virtual ICollection<Options> Options { get; set; }
        public virtual ICollection<QuestionQuiz> QuestionQuiz { get; set; }
    }
}
