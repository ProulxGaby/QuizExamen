﻿using System;
using System.Collections.Generic;

namespace ProjetQuizGabriel.Models
{
    public partial class Categorie
    {
        public Categorie()
        {
            Question = new HashSet<Question>();
        }

        public string Dificulte { get; set; }
        public int CategorieId { get; set; }

        public virtual ICollection<Question> Question { get; set; }
    }
}
