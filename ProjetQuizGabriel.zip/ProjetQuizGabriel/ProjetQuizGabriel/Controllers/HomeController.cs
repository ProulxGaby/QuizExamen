﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using ProjetQuizGabriel.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetQuizGabriel.Controllers
{
    public class HomeController : Controller
    {
        private readonly QuizExamenContext context;

        public HomeController(QuizExamenContext _context)
        {
            context = _context;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult creeQuiz()
        {
            return View();
        }
        [HttpPost]
        public IActionResult creeQuiz2(string NomUtilisateur, string Email, int Facile, int Moyenne, int Difficile)
        {
            Quiz quiz = new Quiz();
            quiz.Email = Email;
            quiz.NomUtilisateur = NomUtilisateur;

            context.Quiz.Add(quiz);
            context.SaveChanges();

            var iD = quiz.QuizId;
            //var iD = context.Quiz.OrderByDescending(m => m.QuizId).First().QuizId;

            var tabF = new HashSet<Question>();
            var tabM = new HashSet<Question>();
            var tabD = new HashSet<Question>();

            Random rnd = new Random();
            if (Facile > 0)
            {
                var qFacile = context.Question.Where(cat => cat.CategorieId == 1).ToList();
                for (int i = 0; i < Facile; i++)
                {
                    var num = rnd.Next(0, qFacile.Count());
                    tabF.Add(qFacile[num]);
                }
                //do
                //{
                    
                //    var num = rnd.Next(0, qFacile.Count());
                //    tabF.Add(qFacile[num]);
                //} while (tabF.Count() == Facile);
            }
            if (Moyenne > 0)
            {
                var qMoyenne = context.Question.Where(cat => cat.CategorieId == 2).ToList();
                for (int i = 0; i < Moyenne; i++)
                {
                    var num = rnd.Next(0, qMoyenne.Count());
                    tabM.Add(qMoyenne[num]);
                }
                //do
                //{

                //} while (tabM.Count() == Moyenne);
            }
            if (Difficile > 0)
            {
                var qDif = context.Question.Where(cat => cat.CategorieId == 3).ToList();
                for (int i = 0; i < Difficile; i++)
                {
                    var num = rnd.Next(0, qDif.Count());
                    tabM.Add(qDif[num]);
                }
                //do
                //{

                //} while (tabD.Count() == Difficile);
            }
            //if (Difficile > 0)
            //{
            //    do
            //    {
            //        var num = rnd.Next(21, 31);
            //        tabD.Add(num);
            //    } while (tabD.Count() <= Difficile);
            //}
            //foreach (var item in context.Question.Where(cat => cat.CategorieId == 1).Take(Facile).ToList())
            //{
            //    QuestionQuiz qQ = new QuestionQuiz();
            //    qQ.QuizId = iD;
            //    qQ.QuestionId = item.QuestionId;
            //    context.QuestionQuiz.Add(qQ);
            //    context.SaveChanges();
            //}
            foreach (var item in tabF)
            {
                QuestionQuiz qQ = new QuestionQuiz();
                qQ.QuizId = iD;
                qQ.QuestionId = item.QuestionId;
                context.QuestionQuiz.Add(qQ);
                context.SaveChanges();
                Console.WriteLine(tabF.Count());
            }
            foreach (var item in tabM)
            {
                QuestionQuiz qQ = new QuestionQuiz();
                qQ.QuizId = iD;
                qQ.QuestionId = item.QuestionId;
                context.QuestionQuiz.Add(qQ);
                context.SaveChanges();
                Console.WriteLine(tabM.Count());
            }
            foreach (var item in tabD)
            {
                QuestionQuiz qQ = new QuestionQuiz();
                qQ.QuizId = iD;
                qQ.QuestionId = item.QuestionId;
                context.QuestionQuiz.Add(qQ);
                context.SaveChanges();
                Console.WriteLine(tabD.Count());
            }
            return View("Index");
        }
        public IActionResult jouerQuiz(string NomUtilisateur, string Email)
        {
            if (NomUtilisateur != null && Email != null)
            {
                var quiz = context.Quiz.Where(q => q.Email == Email && q.NomUtilisateur == NomUtilisateur && q.Reponse.Count() == 0);
                if (quiz.Count() > 0)
                {
                    ViewBag.message = $"Voici le ou les quizs, de {NomUtilisateur}, aux quels vous pouvez jouer.";
                    ViewBag.style = "text-success";
                }
                else
                {
                    ViewBag.message = $"Il n'y a pas de quiz non répondu de {NomUtilisateur}! Veuillez retourner à l'accueil.";
                    ViewBag.style = "text-danger";
                }               
                return View(quiz);
            }
            return View();
        }
        public IActionResult reviserQuiz(string NomUtilisateur, string Email)
        {
            if(NomUtilisateur != null && Email != null)
            {
                var quiz = context.Quiz.Where(q => q.Email == Email && q.NomUtilisateur == NomUtilisateur && q.Reponse.Count() > 0);
                if (quiz.Count() > 0)
                {
                    ViewBag.message = $"Voici les quizs déjà répondu ainsi que les reponses de {NomUtilisateur}";
                    ViewBag.style = "text-success";
                }
                else
                {
                    ViewBag.message = $"Il n'y a aucun quiz que {NomUtilisateur} a passé. Veuillez retourner à l'accueil et choisir jouer ou créer quiz";
                    ViewBag.style = "text-danger";                    
                }
                
                return View(quiz);
            }
            
            return View();
        }
        public IActionResult passeQuiz(int id)//quizId
        {
            var liste = context.QuestionQuiz.Where(q => q.QuizId == id).ToList();
            ViewBag.quizId = id;
            return View(liste);
        }
        public IActionResult soumettreQuiz(int id)// quizId
        {
            
            foreach (var key in HttpContext.Request.Query.Keys)
            {
                
                StringValues someInt;
                HttpContext.Request.Query.TryGetValue(key, out someInt);
                Reponse rep = new Reponse();
                rep.QuizId = id;
                rep.OptionId = Convert.ToInt32(someInt);
                context.Reponse.Add(rep);
                context.SaveChanges();
            }
            return View("index");
        }
        public IActionResult voirQuiz(int id)//quiz id
        {

            var liste2 = context.Reponse.Where(q => q.QuizId == id).ToList();
            ViewBag.choix = liste2;

            var liste = context.QuestionQuiz.Where(q => q.QuizId == id).ToList();

            return View(liste);
        }
    }
}
